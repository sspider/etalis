This directory contains examples of complex event processing with Etalis.
It also acts as a set of regression tests for Etalis.
