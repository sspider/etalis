These are the sources for the interactive system website:

http://krake26.perimeter.fzi.de:8080/etalis

