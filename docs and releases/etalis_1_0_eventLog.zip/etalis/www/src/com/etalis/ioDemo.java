package com.etalis;
//import java.io.*;

public class ioDemo {	
	// Properties
	private String name;
	private String email;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getEmail() {
		return this.email;
	}


}
