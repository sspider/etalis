package com.etalis;

import jpl.Compound;
import jpl.JPL;
import jpl.Query;

public class InitEtalis {
	
	

}
