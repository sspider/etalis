compile.bat
	will compile this demo

run.bat
	will run it

..\README.txt
	may explain what is happening

----

Paul Singleton (paul.singleton@bcs.org.uk)
February 2004

