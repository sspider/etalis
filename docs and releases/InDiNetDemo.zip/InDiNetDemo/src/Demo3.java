import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.jtalis.core.JtalisContextImpl;
import com.jtalis.core.event.EtalisEvent;
import com.jtalis.core.event.provider.DefaultOutputProvider;
import com.jtalis.core.plengine.JPLEngineWrapper;
import com.jtalis.core.plengine.PrologEngineWrapper;


public class Demo3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrologEngineWrapper<?> engine = new JPLEngineWrapper(false);

		JtalisContextImpl ctx = new JtalisContextImpl(engine);
		ctx.compileEvenFile(new File("resources/static03.P"));
		ctx.setEtalisFlags("event_consumption_policy", "recent");

		ctx.addEventTrigger("remadvCount/1");	

		ctx.addDynamicRule("remadvCount(Num1) <- remadv(ID, TS) " +
				"where ( atom_number(TS, TIMESTAMP), " +
				"countNum(TIMESTAMP, Num1) " +
				")"); 
		

		
		ctx.registerOutputProvider(new DefaultOutputProvider());
		

		
		try {

			BufferedReader reader = new BufferedReader(new FileReader("resources/UMC_JOHANNES_REMADV_export.csv"));
			
			// ignore the first line
			reader.readLine();
			String line = null;
			
			while((line = reader.readLine()) != null){

				String item[] = line.split(",");
				DateFormat df = new SimpleDateFormat("dd.MM.yy HH:mm:ss");
				//Date dt1 = df.parse(item[12]);
				
				Date dt2 = df.parse(item[7]);
				
				EtalisEvent tmp = new EtalisEvent("remadv", 
						Long.valueOf(item[item.length-1]), 
						//String.valueOf(dt1.getTime()/1000), 
						String.valueOf(dt2.getTime()/1000));
				
				ctx.pushEvent(tmp);
			}	
			
		} catch (Exception e) {

			e.printStackTrace();

		}
	
		ctx.shutdown();

	}

}

