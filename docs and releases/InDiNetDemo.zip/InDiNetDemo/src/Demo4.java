import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.jtalis.core.JtalisContextImpl;
import com.jtalis.core.event.EtalisEvent;
import com.jtalis.core.event.provider.DefaultOutputProvider;
import com.jtalis.core.plengine.JPLEngineWrapper;
import com.jtalis.core.plengine.PrologEngineWrapper;


public class Demo4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrologEngineWrapper<?> engine = new JPLEngineWrapper(false);

		JtalisContextImpl ctx = new JtalisContextImpl(engine);
		ctx.compileEvenFile(new File("resources/static04.P"));
		ctx.setEtalisFlags("event_consumption_policy", "recent");

		ctx.addEventTrigger("notPayAmount/1");	

		ctx.addDynamicRule("notPayAmount(TOTAL) <- remadv(TS,PAYAMOUNT,'0') " +
				"where ( atom_number(TS, TIMESTAMP), " +
				"countPAY(TIMESTAMP, PAYAMOUNT, TOTAL) " +
				")"); 
		

		
		ctx.registerOutputProvider(new DefaultOutputProvider());
		

		
		try {

			BufferedReader reader = new BufferedReader(new FileReader("resources/UMC_JOHANNES_REMADV_export.csv"));
			
			// ignore the first line
			reader.readLine();
			String line = null;
			
			while((line = reader.readLine()) != null){

				String item[] = line.split(",");
				DateFormat df = new SimpleDateFormat("dd.MM.yy HH:mm:ss");
				//Date dt1 = df.parse(item[12]);
				
				Date dt2 = df.parse(item[7]);
				
				EtalisEvent tmp = new EtalisEvent("remadv",  
						String.valueOf(dt2.getTime()/1000),
						Float.valueOf(item[item.length-3]),
						item[item.length-2]);
				
				ctx.pushEvent(tmp);
			}	
			
		} catch (Exception e) {

			e.printStackTrace();

		}
	
		ctx.shutdown();

	}

}
