package com.etalis;

public class ioEtalis {
	//Properties
	private String inputterm;
	private String inputrules;
	

}
