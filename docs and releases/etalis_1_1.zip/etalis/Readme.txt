This is the public release of the complex event processing system ETALIS ( http://code.google.com/p/etalis ).

ETALIS is distributed under the source code license: GNU Lesser General Public License.

Prolog backend compatibility:
As of 2010, supported back-end Prolog systems include XSB, SWI, YAP and SICStus Prolog.

Please consult the user manual in "docs/userman" for installing and using ETALIS.

Please contact Paul Fodor <pfodor@cs.stonybrook.edu> and Darko Anicic <darko.anicic@fzi.de> for any problems with the execution of the ETALIS programs.
