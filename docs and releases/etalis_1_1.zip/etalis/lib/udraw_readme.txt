http://www.informatik.uni-bremen.de/uDrawGraph/en/download/download.html

is used for creating graphs for justification

Udraw has a license similar to GNU Lesser General Public License.

Please refer to their website for references.
