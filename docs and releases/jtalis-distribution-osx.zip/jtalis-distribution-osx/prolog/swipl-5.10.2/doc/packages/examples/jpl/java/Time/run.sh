#!/bin/sh

. ../env.sh

run Time

